import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String todo;
  bool isComplete = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Container(
                color: Colors.blueAccent,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      'TodoList',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                        child: Card(
                          elevation: 5,
                          color: Colors.white,
                          child: ListTile(
                            leading: Icon(Icons.add_box),
                            title: TextField(
                              onChanged: (value) {
                                setState(() {
                                  todo = value;
                                });
                              },
                              decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Enter a new todo'),
                            ),
                            trailing: GestureDetector(
                              onTap: () {
                                if (todo != '') {
                                  print(todo);
                                }
                              },
                              child: Icon(Icons.arrow_forward),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  child: ListView(
                    children: <Widget>[
                      ListTile(
                        leading: Icon(
                          Icons.done_all,
                          color: Colors.blue,
                        ),
                        title: Text('A new todo'),
                        trailing: Icon(
                          Icons.delete,
                          color: Colors.red,
                        ),
                      ),
                      Divider(
                        color: Colors.grey,
                      ),
                      ListTile(
                        leading: Icon(
                          Icons.done,
                          color: Colors.grey,
                        ),
                        title: Text('Another task to be done'),
                        trailing: Icon(
                          Icons.delete,
                          color: Colors.red,
                        ),
                      ),
                      Divider(
                        color: Colors.grey,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
